import React from "react";
import { Navbar1 } from "./components/Navbar1";
import { Header44 } from "./components/Header44";
import { Layout25 } from "./components/Layout25";
import { Layout1 } from "./components/Layout1";
import { Layout3 } from "./components/Layout3";
import { Testimonial6 } from "./components/Testimonial6";
import { Layout352 } from "./components/Layout352";
import { Contact15 } from "./components/Contact15";
import { Footer1 } from "./components/Footer1";

export default function Page() {
  return (
    <div>
      <Navbar1 />
      <Header44 />
      <Layout25 />
      <Layout1 />
      <Layout3 />
      <Testimonial6 />
      <Layout352 />
      <Contact15 />
      <Footer1 />
    </div>
  );
}
