import React from "react";
import { Navbar1 } from "./components/Navbar1";
import { Header9 } from "./components/Header9";
import { Layout102 } from "./components/Layout102";
import { Layout102_1 } from "./components/Layout102_1";
import { Layout241 } from "./components/Layout241";
import { Layout101 } from "./components/Layout101";
import { Pricing24 } from "./components/Pricing24";
import { Layout373 } from "./components/Layout373";
import { Cta19 } from "./components/Cta19";
import { Blog34 } from "./components/Blog34";
import { Contact16 } from "./components/Contact16";
import { Footer1 } from "./components/Footer1";

export default function Page() {
  return (
    <div>
      <Navbar1 />
      <Header9 />
      <Layout102 />
      <Layout102_1 />
      <Layout241 />
      <Layout101 />
      <Pricing24 />
      <Layout373 />
      <Cta19 />
      <Blog34 />
      <Contact16 />
      <Footer1 />
    </div>
  );
}
