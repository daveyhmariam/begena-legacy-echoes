import React from "react";
import { Navbar1 } from "./components/Navbar1";
import { Header49 } from "./components/Header49";
import { Layout90 } from "./components/Layout90";
import { Layout238 } from "./components/Layout238";
import { Layout250 } from "./components/Layout250";
import { Pricing25 } from "./components/Pricing25";
import { Cta7 } from "./components/Cta7";
import { Contact13 } from "./components/Contact13";
import { Footer1 } from "./components/Footer1";

export default function Page() {
  return (
    <div>
      <Navbar1 />
      <Header49 />
      <Layout90 />
      <Layout238 />
      <Layout250 />
      <Pricing25 />
      <Cta7 />
      <Contact13 />
      <Footer1 />
    </div>
  );
}
