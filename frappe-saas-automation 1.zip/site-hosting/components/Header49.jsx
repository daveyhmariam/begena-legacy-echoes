"use client";

import React from "react";

export function Header49() {
  return (
    <section id="relume" className="px-[5%] py-16 md:py-24 lg:py-28">
      <div className="container">
        <div className="grid grid-cols-1 items-start gap-x-12 gap-y-5 md:grid-cols-2 lg:gap-x-20 lg:gap-y-16">
          <div>
            <h1 className="text-6xl font-bold md:text-9xl lg:text-10xl">
              Site Hosting Plans
            </h1>
          </div>
          <div>
            <p className="md:text-md">
              Discover affordable and reliable hosting solutions tailored for
              small businesses and startups. Our entry-level plans provide the
              perfect balance of performance and cost-effectiveness to help you
              launch your Frappe/ERPNext site with ease.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
