"use client";

import React from "react";

export function Layout194() {
  return (
    <section id="relume" className="px-[5%] py-16 md:py-24 lg:py-28">
      <div className="container">
        <div className="grid grid-cols-1 items-center gap-12 md:grid-cols-2 lg:gap-x-20">
          <div className="order-2 md:order-1">
            <img
              src="https://d22po4pjz3o32e.cloudfront.net/placeholder-image.svg"
              className="w-full object-cover"
              alt="Relume placeholder image"
            />
          </div>
          <div className="order-1 md:order-2">
            <h3 className="mb-5 text-4xl font-bold leading-[1.2] md:mb-6 md:text-5xl lg:text-6xl">
              Unlock Enhanced Control and Flexibility with Our Dedicated Bench
              Hosting.
            </h3>
            <p className="md:text-md">
              Experience the full power of our shared hosting features while
              gaining the autonomy to manage multiple sites. Perfect for growing
              businesses, our Dedicated Bench offers advanced monitoring and
              priority support to ensure your operations run smoothly.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
