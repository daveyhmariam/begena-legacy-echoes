import React from "react";
import { Navbar1 } from "./components/Navbar1";
import { Header54 } from "./components/Header54";
import { Layout194 } from "./components/Layout194";
import { Layout18 } from "./components/Layout18";
import { Layout1 } from "./components/Layout1";
import { Layout239 } from "./components/Layout239";
import { Layout246 } from "./components/Layout246";
import { Cta1 } from "./components/Cta1";
import { Pricing5 } from "./components/Pricing5";
import { Contact19 } from "./components/Contact19";
import { Footer1 } from "./components/Footer1";

export default function Page() {
  return (
    <div>
      <Navbar1 />
      <Header54 />
      <Layout194 />
      <Layout18 />
      <Layout1 />
      <Layout239 />
      <Layout246 />
      <Cta1 />
      <Pricing5 />
      <Contact19 />
      <Footer1 />
    </div>
  );
}
