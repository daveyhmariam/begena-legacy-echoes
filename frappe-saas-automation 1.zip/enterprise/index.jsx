import React from "react";
import { Navbar1 } from "./components/Navbar1";
import { Header15 } from "./components/Header15";
import { Layout3 } from "./components/Layout3";
import { Layout12 } from "./components/Layout12";
import { Layout237 } from "./components/Layout237";
import { Layout1 } from "./components/Layout1";
import { Layout12_1 } from "./components/Layout12_1";
import { Layout240 } from "./components/Layout240";
import { Pricing14 } from "./components/Pricing14";
import { Cta27 } from "./components/Cta27";
import { Testimonial1 } from "./components/Testimonial1";
import { Contact17 } from "./components/Contact17";
import { Footer1 } from "./components/Footer1";

export default function Page() {
  return (
    <div>
      <Navbar1 />
      <Header15 />
      <Layout3 />
      <Layout12 />
      <Layout237 />
      <Layout1 />
      <Layout12_1 />
      <Layout240 />
      <Pricing14 />
      <Cta27 />
      <Testimonial1 />
      <Contact17 />
      <Footer1 />
    </div>
  );
}
